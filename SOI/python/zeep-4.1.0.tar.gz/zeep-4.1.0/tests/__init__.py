from zeep.client import Client  # noqa
from zeep.exceptions import Fault  # noqa
