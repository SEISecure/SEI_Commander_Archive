Authors
=======
* Michael van Tellingen

Contributors
============

* Kateryna Burda
* Alexey Stepanov
* Marco Vellinga
* jaceksnet
* Andrew Serong
* vashek
* Seppo Yli-Olli
* Sam Denton
* Dani Möller
* Julien Delasoie
* Christian González
* bjarnagin
* mcordes
* Joeri Bekker
* Bartek Wójcicki
* jhorman
* fiebiga
* David Baumgold
* Antonio Cuni
* Alexandre de Mari
* Nicolas Evrard
* Eric Wong
* Jason Vertrees
* Falldog
* Matt Grimm (mgrimm)
* Marek Wywiał
* btmanm
* Caleb Salt
* Ondřej Lanč
* Jan Murre
* Stefano Parmesan
* Julien Marechal
* Dave Wapstra
* Mike Fiedler
* Derek Harland
* Bruno Duyé
* Christoph Heuel
* Ben Tucker
* Eric Waller
* Falk Schuetzenmeister
* Jon Jenkins
* OrangGeeGee
* Raymond Piller
* Zoltan Benedek
* Øyvind Heddeland Instefjord
* Pol Sanlorenzo

